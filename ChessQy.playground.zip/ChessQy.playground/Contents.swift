import Foundation

struct Point: Hashable,Equatable {
    let x: Int
    let y: Int
    
    static func == (lhs: Point, rhs: Point) -> Bool {
        return lhs.x == rhs.x && lhs.y == rhs.y
    }
}

struct ChessPoint: Hashable, Equatable {
    let point: Point
    var impactedPoints: Set<Point>
    
    var impactionIndex: Int {
        return impactedPoints.count
    }
    
    static func == (lhs: ChessPoint, rhs: ChessPoint) -> Bool {
        return lhs.point == rhs.point && lhs.impactedPoints == rhs.impactedPoints
    }
}

struct SetOfPoints {
    let dimension: Int
    var allImpactedPoints = Set<Point>()
    var allPoints = Set<ChessPoint>()
    var queensLocation = [Point]()
    
    init(n: Int) {
        self.dimension = n
        
        setInitialPoints()
    }
    
    private mutating func setInitialPoints() {
        for i in 0..<dimension {
            for j in 0..<dimension {
                let point = Point(x: i, y: j)
                let impactedPoints = impaction(of: point)
                let chessPoint = ChessPoint(point: point, impactedPoints: impactedPoints)
                allPoints.insert(chessPoint)
            }
        }
    }
    
    private func updateImpaction() {
        allPoints.map {ChessPoint(point: $0.point, impactedPoints: impaction(of: $0.point))}
    }
    
    private func impaction(of point: Point) -> Set<Point> {
        var result =  Set<Point>()
        
        result.formUnion(xSameYIncreased(point: point))
        result.formUnion(xSameYDiscreased(point: point))
        result.formUnion(xIncreasedYSame(point: point))
        result.formUnion(xDiscreasedYSame(point: point))
        result.formUnion(xyIncreased(point: point))
        result.formUnion(xyDiscreased(point: point))
        result.formUnion(xIncreasedYDiscreased(point: point))
        result.formUnion(xDiscreasedYIncreased(point: point))
        result.insert(point)
        
        return result
    }
    
    private func xSameYIncreased(point: Point)-> [Point] {
        var i = 1
        var result = [Point]()
        
        while (point.y + i < dimension) {
            let point = Point(x: point.x , y: point.y + i)
            
            i += 1
            
            if !allImpactedPoints.contains(where: { $0.x == point.x && $0.y == point.y }) {
                result.append(point)
            }
        }
        return result
    }
    
    private func xSameYDiscreased(point: Point)-> [Point] {
        var i = 1
        var result = [Point]()
        
        while (0 <= point.y - i) {
            let point = Point(x: point.x , y: point.y - i)
            
            i += 1
            
            if !allImpactedPoints.contains(where: { $0.x == point.x && $0.y == point.y }) {
                result.append(point)
            }
        }
        return result
    }
    
    private func xIncreasedYSame(point: Point)-> [Point] {
        var i = 1
        var result = [Point]()
        
        while (point.x + i < dimension) {
            let point = Point(x: point.x + i , y: point.y)
            
            i += 1
            
            if !allImpactedPoints.contains(where: { $0.x == point.x && $0.y == point.y }) {
                result.append(point)
            }
        }
        return result
    }
    
    private func xDiscreasedYSame(point: Point)-> [Point] {
        var i = 1
        var result = [Point]()
        
        while (0 <= point.x - i) {
            let point = Point(x: point.x - i, y: point.y)
            
            i += 1
            
            if !allImpactedPoints.contains(where: { $0.x == point.x && $0.y == point.y }) {
                result.append(point)
            }
        }
        return result
    }
    
    private func xyIncreased(point: Point)-> [Point] {
        var i = 1
        var result = [Point]()
        
        while (point.y + i < dimension && point.x + i < dimension) {
            let point = Point(x: point.x + i, y: point.y + i)
            
            i += 1
            
            if !allImpactedPoints.contains(where: { $0.x == point.x && $0.y == point.y }) {
                result.append(point)
            }
        }
        return result
    }
    
    private func xyDiscreased(point: Point)-> [Point] {
        var i = 1
        var result = [Point]()
        
        while (0 <= point.y - i && 0 <= point.x - i) {
            let point = Point(x: point.x - i, y: point.y - i)
            
            i += 1
            
            if !allImpactedPoints.contains(where: { $0.x == point.x && $0.y == point.y }) {
                result.append(point)
            }
        }
        return result
    }
    
    private func xIncreasedYDiscreased(point: Point)-> [Point] {
        var i = 1
        var result = [Point]()
        
        while (point.x + i < dimension && 0 <= point.y - i) {
            let point = Point(x: point.x + i, y: point.y - i)
            
            i += 1
            
            if !allImpactedPoints.contains(where: { $0.x == point.x && $0.y == point.y }) {
                result.append(point)
            }
        }
        return result
    }
    
    private func xDiscreasedYIncreased(point: Point)-> [Point] {
        var i = 1
        var result = [Point]()
        
        while (0 <= point.x - i  &&  point.y + i < dimension) {
            let point = Point(x: point.x - i, y: point.y + i)
            
            i += 1
            
            if !allImpactedPoints.contains(where: { $0.x == point.x && $0.y == point.y }) {
                result.append(point)
            }
        }
        return result
    }
    
    private func bestPointForPlacingQueen() -> ChessPoint? {
        return allPoints.min(by: {$0.impactionIndex < $1.impactionIndex})
    }
    
    private func getImpaction(of point: Point) -> ChessPoint? {
        return allPoints.first{ $0.point == point }
    }
    
    
    mutating func setQueen() {
        
        guard let bestPoint = bestPointForPlacingQueen() else {
            print("bestPoint is nil")
            return
        }
        queensLocation.append(bestPoint.point)
        allImpactedPoints.formUnion(bestPoint.impactedPoints)
        allPoints = allPoints.filter { !bestPoint.impactedPoints.contains($0.point)}
        
        var updatedAllPoints = Set<ChessPoint>()
        for i in allPoints {
            let chessPoint = ChessPoint(point: i.point, impactedPoints: i.impactedPoints.filter { _ in !bestPoint.impactedPoints.contains(i.point) })
            updatedAllPoints.insert(chessPoint)
        }
        allPoints = updatedAllPoints
    }
}

struct Game {
    var board: SetOfPoints
    var numberOfPlacedQueens: Int = 0
    let start = CFAbsoluteTimeGetCurrent()
    var numberOfAttempts = 1
    
    mutating func startGame() {
        resetBoard()
        while (board.allPoints.count > 0) {
            board.setQueen()
            numberOfPlacedQueens += 1
        }
        endGame()
    }
    
    mutating func endGame() {
        if numberOfPlacedQueens < board.dimension {
            print("There isn't finded solution for \(numberOfAttempts) try.\nAlgorithm is running again, please wait...")
            numberOfAttempts += 1
            if numberOfAttempts < 100 {
                startGame()
            } else {
                print("I tried a hundred time to find solution, but unfortunately haven't found. I don't know, if there is exist solution or not :(((")
                let diff = CFAbsoluteTimeGetCurrent() - start
                print("Program execution took \(diff) seconds")
                return
            }
           
        } else {
            print("Congratulations, here is one of solutions:")
            board.queensLocation.forEach {
                print($0)
            }
            let diff = CFAbsoluteTimeGetCurrent() - start
            print("Program execution took \(diff) seconds")
        }
    }
    
    mutating func resetBoard() {
        board = SetOfPoints(n: board.dimension)
        numberOfPlacedQueens = 0
    }
}

// change the n, and get the solution. Have a fun:)))
var game = Game(board: SetOfPoints(n: 8))
game.startGame()

